#include <iostream>
using namespace std;

class DynamicArray {
private:
    int* array;   // Pointer to dynamically allocated array
    int arraySize; // Size of the array

public:
    // Constructor to initialize the array with a specified size
    DynamicArray(int size) : arraySize(size) {
        if (size < 0) {
            throw std::out_of_range("Array size must be non-negative.");
        }
        array = new int[size](); // Initialize with zeros
    }

    // Copy constructor
    DynamicArray(const DynamicArray& other) : arraySize(other.arraySize) {
        array = new int[arraySize];
        for (int i = 0; i < arraySize; ++i) {
            array[i] = other.array[i];
        }
    }

    // Move constructor
    DynamicArray(DynamicArray&& other) noexcept : array(other.array), arraySize(other.arraySize) {
        other.array = nullptr;
        other.arraySize = 0;
    }

    // Destructor to properly release allocated memory
    ~DynamicArray() {
        delete[] array;
    }

    // Overload [] for accessing product quantities by index with boundary checking
    int& operator[](int index) {
        if (index < 0 || index >= arraySize) {
            throw out_of_range("Index out of bounds.");
        }
        return array[index];
    }

    // Overload [] for const access
    const int& operator[](int index) const {
        if (index < 0 || index >= arraySize) {
            throw out_of_range("Index out of bounds.");
        }
        return array[index];
    }

    // Overload = for assigning one dynamic array to another
    DynamicArray& operator=(const DynamicArray& other) {
        if (this != &other) {
            delete[] array; // Free existing resource
            arraySize = other.arraySize;
            array = new int[arraySize];
            for (int i = 0; i < arraySize; ++i) {
                array[i] = other.array[i];
            }
        }
        return *this;
    }

    // Overload = for move assignment
    DynamicArray& operator=(DynamicArray&& other) noexcept {
        if (this != &other) {
            delete[] array; // Free existing resource
            array = other.array;
            arraySize = other.arraySize;
            other.array = nullptr;
            other.arraySize = 0;
        }
        return *this;
    }

    // Overload += for element-wise addition of quantities
    DynamicArray& operator+=(const DynamicArray& other) {
        if (arraySize != other.arraySize) {
            throw std::invalid_argument("Arrays must be of the same size for element-wise addition.");
        }
        for (int i = 0; i < arraySize; ++i) {
            array[i] += other.array[i];
        }
        return *this;
    }

    // Overload + for creating a new dynamic array that represents the total quantities of two arrays
    DynamicArray operator+(const DynamicArray& other) const {
        if (arraySize != other.arraySize) {
            throw std::invalid_argument("Arrays must be of the same size for addition.");
        }
        DynamicArray result(arraySize);
        for (int i = 0; i < arraySize; ++i) {
            result.array[i] = array[i] + other.array[i];
        }
        return result;
    }

    // Overload << for providing a formatted output of the dynamic array's contents
    friend ostream& operator<<(ostream& os, const DynamicArray& arr) {
        for (int i = 0; i < arr.arraySize; ++i) {
            os << arr.array[i];
            if (i < arr.arraySize - 1) {
                os << ", ";
            }
        }
        return os;
    }

    // Size method to return the total number of products in the inventory
    int size() const {
        return arraySize;
    }
};

int main() {
    DynamicArray inventory1(5); // Create a dynamic array with 5 product quantities
    DynamicArray inventory2(5); // Create another dynamic array with 5 product quantities

    // Initialize the inventories
    for (int i = 0; i < 5; ++i) {
        inventory1[i] = i * 10; // inventory1: {0, 10, 20, 30, 40}
        inventory2[i] = i * 5;  // inventory2: {0, 5, 10, 15, 20}
    }

    // Perform element-wise addition
    inventory1 += inventory2; // inventory1: {0, 15, 30, 45, 60}

    // Create a new inventory by adding two inventories
    DynamicArray totalInventory = inventory1 + inventory2; // totalInventory: {0, 20, 40, 60, 80}

    // Output the contents of the total inventory
    cout << "Total Inventory: " << totalInventory << endl;

    // Get the size of the inventory
    cout << "Total products: " << totalInventory.size() << endl;

    return 0;
}
