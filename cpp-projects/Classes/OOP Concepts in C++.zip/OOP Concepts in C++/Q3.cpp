#include <iostream>
#include <cstdio>  // For FILE, fopen, fclose, fprintf, fscanf
#include <stdexcept>
#include <iomanip>

using namespace std;

class Matrix {
private:
    int rows, cols;
    float** data;

    void allocateMemory() {
        data = new float*[rows];
        for (int i = 0; i < rows; ++i) {
            data[i] = new float[cols]();
        }
    }

    void deallocateMemory() {
        for (int i = 0; i < rows; ++i) {
            delete[] data[i];
        }
        delete[] data;
    }

public:
    // Constructors
    Matrix() : rows(0), cols(0), data(nullptr) {}

    Matrix(int r, int c) : rows(r), cols(c) {
        allocateMemory();
    }

    Matrix(const Matrix& other) : rows(other.rows), cols(other.cols) {
        allocateMemory();
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                data[i][j] = other.data[i][j];
            }
        }
    }

    ~Matrix() {
        deallocateMemory();
    }

    // Overloaded new and delete operators
    void* operator new(size_t size) {
        return ::operator new(size);
    }

    void operator delete(void* pointer) {
        ::operator delete(pointer);
    }

    // Matrix Operations
    Matrix operator+(const Matrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw runtime_error("Matrix dimensions do not match for addition.");
        }
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[i][j] = data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator-(const Matrix& other) const {
        if (rows != other.rows || cols != other.cols) {
            throw runtime_error("Matrix dimensions do not match for subtraction.");
        }
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[i][j] = data[i][j] - other.data[i][j];
            }
        }
        return result;
    }

    Matrix operator*(const Matrix& other) const {
        if (cols != other.rows) {
            throw runtime_error("Matrix dimensions do not match for multiplication.");
        }
        Matrix result(rows, other.cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < other.cols; ++j) {
                result.data[i][j] = 0;
                for (int k = 0; k < cols; ++k) {
                    result.data[i][j] += data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }

    Matrix operator*(float scalar) const {
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[i][j] = data[i][j] * scalar;
            }
        }
        return result;
    }

    // Overloaded input/output operators
    friend ostream& operator<<(ostream& os, const Matrix& m) {
        for (int i = 0; i < m.rows; ++i) {
            for (int j = 0; j < m.cols; ++j) {
                os << setw(10) << m.data[i][j] << ' ';
            }
            os << endl;
        }
        return os;
    }

    friend istream& operator>>(istream& is, Matrix& m) {
        for (int i = 0; i < m.rows; ++i) {
            for (int j = 0; j < m.cols; ++j) {
                is >> m.data[i][j];
            }
        }
        return is;
    }

    // Overloaded comparison operators
    bool operator==(const Matrix& other) const {
        if (rows != other.rows || cols != other.cols) return false;
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                if (data[i][j] != other.data[i][j]) return false;
            }
        }
        return true;
    }

    bool operator!=(const Matrix& other) const {
        return !(*this == other);
    }

    // Overloaded () operator for element access with boundary checking
    float& operator()(int r, int c) {
        if (r < 0 || r >= rows || c < 0 || c >= cols) {
            throw out_of_range("Index out of bounds");
        }
        return data[r][c];
    }

    // Overloaded unary - operator to negate all elements of the matrix
    Matrix operator-() const {
        Matrix result(rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[i][j] = -data[i][j];
            }
        }
        return result;
    }

    // Additional Features
    Matrix transpose() const {
        Matrix result(cols, rows);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                result.data[j][i] = data[i][j];
            }
        }
        return result;
    }

    // File Handling using C-style file I/O
    void saveToFile(const string& filename) const {
        FILE* file = fopen(filename.c_str(), "w");
        if (!file) {
            throw runtime_error("Unable to open file for writing.");
        }
        fprintf(file, "%d %d\n", rows, cols);
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                fprintf(file, "%.2f ", data[i][j]);
            }
            fprintf(file, "\n");
        }
        fclose(file);
    }

    void loadFromFile(const string& filename) {
        FILE* file = fopen(filename.c_str(), "r");
        if (!file) {
            throw runtime_error("Unable to open file for reading.");
        }
        deallocateMemory();
        fscanf(file, "%d %d", &rows, &cols);
        allocateMemory();
        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < cols; ++j) {
                fscanf(file, "%f", &data[i][j]);
            }
        }
        fclose(file);
    }
};

int main() {
    try {
        Matrix m1(2, 2);
        Matrix m2(2, 2);

        cout << "Enter elements for Matrix 1:" << endl;
        cin >> m1;
        cout << "Enter elements for Matrix 2:" << endl;
        cin >> m2;

        Matrix m3 = m1 + m2;
        cout << "Matrix 1 + Matrix 2:" << endl;
        cout << m3;

        Matrix m4 = m1 * 2.0;
        cout << "Matrix 1 * 2.0:" << endl;
        cout << m4;

        m1.saveToFile("matrix.txt");

        Matrix m5;
        m5.loadFromFile("matrix.txt");
        cout << "Loaded Matrix:" << endl;
        cout << m5;
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}
