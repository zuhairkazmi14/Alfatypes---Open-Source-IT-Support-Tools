#include <iostream>
#include <string>
#include <cmath>

using namespace std;

class conversion {
private:
    string conversionString;
    int base;

    // Helper function to convert a number from any base to decimal (base 10)
    int toDecimal(const string& str, int base) const {
        int num = 0;
        int power = 0;
        for (int i = str.length() - 1; i >= 0; i--) {
            char digit = str[i];
            if (digit >= '0' && digit <= '9') {
                num += (digit - '0') * pow(base, power);
            } else if (digit >= 'A' && digit <= 'F') {
                num += (digit - 'A' + 10) * pow(base, power);
            }
            power++;
        }
        return num;
    }

    // Helper function to convert a number from decimal (base 10) to any base
    string toBase(int num, int base) const {
        if (num == 0) return "0";
        string result = "";
        while (num > 0) {
            int remainder = num % base;
            if (remainder < 10) {
                result = char(remainder + '0') + result;
            } else {
                result = char(remainder - 10 + 'A') + result;
            }
            num /= base;
        }
        return result;
    }

public:
    // Constructor
    conversion(string conversionStr, int base) : conversionString(conversionStr), base(base) {
        // Convert the input string to decimal and then back to the given base to ensure it's in the correct format
        int decimalValue = toDecimal(conversionStr, base);
        conversionString = toBase(decimalValue, base);
    }

    // Overloading + operator for addition
    conversion operator+(const conversion& other) const {
        int result = toDecimal(this->conversionString, this->base) + toDecimal(other.conversionString, other.base);
        return conversion(toBase(result, max(this->base, other.base)), max(this->base, other.base));
    }

    // Overloading - operator for subtraction
    conversion operator-(const conversion& other) const {
        int result = toDecimal(this->conversionString, this->base) - toDecimal(other.conversionString, other.base);
        return conversion(toBase(result, max(this->base, other.base)), max(this->base, other.base));
    }

    // Overloading += operator for addition
    conversion& operator+=(const conversion& other) {
        int result = toDecimal(this->conversionString, this->base) + toDecimal(other.conversionString, other.base);
        this->conversionString = toBase(result, max(this->base, other.base));
        this->base = max(this->base, other.base);
        return *this;
    }

    // Overloading -= operator for subtraction
    conversion& operator-=(const conversion& other) {
        int result = toDecimal(this->conversionString, this->base) - toDecimal(other.conversionString, other.base);
        this->conversionString = toBase(result, max(this->base, other.base));
        this->base = max(this->base, other.base);
        return *this;
    }

    // Overloading * operator for multiplication
    conversion operator*(const conversion& other) const {
        int result = toDecimal(this->conversionString, this->base) * toDecimal(other.conversionString, other.base);
        return conversion(toBase(result, max(this->base, other.base)), max(this->base, other.base));
    }

    // Overloading / operator for division
    conversion operator/(const conversion& other) const {
        int result = toDecimal(this->conversionString, this->base) / toDecimal(other.conversionString, other.base);
        return conversion(toBase(result, max(this->base, other.base)), max(this->base, other.base));
    }

    // Overloading % operator for modulus
    conversion operator%(const conversion& other) const {
        int result = toDecimal(this->conversionString, this->base) % toDecimal(other.conversionString, other.base);
        return conversion(toBase(result, max(this->base, other.base)), max(this->base, other.base));
    }

    // Overloading | operator for or
    conversion operator|(const conversion& other) const {
        int result = toDecimal(this->conversionString, 2) | toDecimal(other.conversionString, 2);
        return conversion(toBase(result, 2), 2);
    }

    // Overloading ^ operator for xor
    conversion operator^(const conversion& other) const {
        int result = toDecimal(this->conversionString, 2) ^ toDecimal(other.conversionString, 2);
        return conversion(toBase(result, 2), 2);
    }

    // Overloading & operator for and
    conversion operator&(const conversion& other) const {
        int result = toDecimal(this->conversionString, 2) & toDecimal(other.conversionString, 2);
        return conversion(toBase(result, 2), 2);
    }

    // Overloading ! operator for 2's Complement
    conversion operator!() const {
        int num = toDecimal(this->conversionString, 2);
        int result = (~num + 1);
        return conversion(toBase(result, 2), 2);
    }

    // Overloading ~ operator for 1's Complement
    conversion operator~() const {
        int num = toDecimal(this->conversionString, 2);
        int result = ~num;
        return conversion(toBase(result, 2), 2);
    }

    // Overloading left shift operator
    conversion operator<<(int shiftAmount) const {
        int num = toDecimal(this->conversionString, 2);
        int result = num << shiftAmount;
        return conversion(toBase(result, 2), 2);
    }

    // Overloading right shift operator
    conversion operator>>(int shiftAmount) const {
        int num = toDecimal(this->conversionString, 2);
        int result = num >> shiftAmount;
        return conversion(toBase(result, 2), 2);
    }

    // Overloading input operator
    friend istream& operator>>(istream& input, conversion& other) {
        input >> other.conversionString >> other.base;
        int decimalValue = other.toDecimal(other.conversionString, other.base);
        other.conversionString = other.toBase(decimalValue, other.base);
        return input;
    }

    // Overloading output operator
    friend ostream& operator<<(ostream& output, const conversion& other) {
        int decimalValue = other.toDecimal(other.conversionString, other.base);
        output << "Base-" << other.base << " Value: " << other.conversionString << " (Decimal: " << decimalValue << ")";
        return output;
    }
};

int main() {
    conversion a("1010", 2);
    conversion b("1001", 2);

    cout << "a: " << a << endl;
    cout << "b: " << b << endl;

    conversion c = a + b;
    cout << "a + b: " << c << endl;

    c = a - b;
    cout << "a - b: " << c << endl;

    c = a * b;
    cout << "a * b: " << c << endl;

    c = a / b;
    cout << "a / b: " << c << endl;

    c = a % b;
    cout << "a % b: " << c << endl;

    c = a | b;
    cout << "a | b: " << c << endl;

    c = a ^ b;
    cout << "a ^ b: " << c << endl;

    c = a & b;
    cout << "a & b: " << c << endl;

    c = !a;
    cout << "!a: " << c << endl;

    c = ~a;
    cout << "~a: " << c << endl;

    c = a << 2;
    cout << "a << 2: " << c << endl;

    c = a >> 2;
    cout << "a >> 2: " << c << endl;

    return 0;
}
