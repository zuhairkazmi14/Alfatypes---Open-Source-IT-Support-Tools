#include <iostream>
#include <stdexcept>

using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

    // Function to compute GCD of two numbers
    int gcd(int a, int b) const {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    // Function to reduce the fraction
    void reduce() {
        if (denominator == 0) {
            throw runtime_error("Denominator cannot be zero.");
        }
        int gcd_val = gcd(abs(numerator), abs(denominator));
        numerator /= gcd_val;
        denominator /= gcd_val;
        if (denominator < 0) { // Keep denominator positive
            numerator = -numerator;
            denominator = -denominator;
        }
    }

public:
    // Constructors
    Rational() : numerator(0), denominator(1) {}

    Rational(int num, int denom) : numerator(num), denominator(denom) {
        reduce();
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {}

    // Destructor
    ~Rational() {}

    // Operator Overloading
    Rational operator+(const Rational& other) const {
        int new_numerator = numerator * other.denominator + other.numerator * denominator;
        int new_denominator = denominator * other.denominator;
        Rational result(new_numerator, new_denominator);
        return result;
    }

    Rational operator-(const Rational& other) const {
        int new_numerator = numerator * other.denominator - other.numerator * denominator;
        int new_denominator = denominator * other.denominator;
        Rational result(new_numerator, new_denominator);
        return result;
    }

    Rational operator*(const Rational& other) const {
        int new_numerator = numerator * other.numerator;
        int new_denominator = denominator * other.denominator;
        Rational result(new_numerator, new_denominator);
        return result;
    }

    Rational operator/(const Rational& other) const {
        if (other.numerator == 0) {
            throw runtime_error("Cannot divide by zero.");
        }
        int new_numerator = numerator * other.denominator;
        int new_denominator = denominator * other.numerator;
        Rational result(new_numerator, new_denominator);
        return result;
    }

    bool operator==(const Rational& other) const {
        return numerator == other.numerator && denominator == other.denominator;
    }

    bool operator!=(const Rational& other) const {
        return !(*this == other);
    }

    friend ostream& operator<<(ostream& os, const Rational& rational) {
        os << rational.numerator << '/' << rational.denominator;
        return os;
    }

    friend istream& operator>>(istream& is, Rational& rational) {
        char slash;
        is >> rational.numerator >> slash >> rational.denominator;
        if (rational.denominator == 0) {
            throw runtime_error("Denominator cannot be zero.");
        }
        rational.reduce();
        return is;
    }
};

int main() {
    try {
        Rational r1(1, 2); // Represents the fraction 1/2
        Rational r2(1, 3); // Represents the fraction 1/3

        Rational r3 = r1 + r2;
        cout << "r1 + r2 = " << r3 << endl; // Should display 5/6

        Rational r4 = r1 - r2;
        cout << "r1 - r2 = " << r4 << endl; // Should display 1/6

        Rational r5 = r1 * r2;
        cout << "r1 * r2 = " << r5 << endl; // Should display 1/6

        Rational r6 = r1 / r2;
        cout << "r1 / r2 = " << r6 << endl; // Should display 3/2

        cout << (r1 == r2) << endl; // Should display 0 (false)
        cout << (r1 != r2) << endl; // Should display 1 (true)

        Rational r7;
        cout << "Enter a rational number (format numerator/denominator): ";
        cin >> r7;
        cout << "You entered: " << r7 << endl;

    } catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
    }

    return 0;
}
