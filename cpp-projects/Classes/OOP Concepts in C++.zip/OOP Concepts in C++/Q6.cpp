#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

const int MAX_COURSES = 100;             // Maximum number of courses
const int MAX_STUDENTS_PER_COURSE = 6;   // Maximum number of students per course

class EnrollmentMap {
private:
    struct Course {
        string name;
        string students[MAX_STUDENTS_PER_COURSE];
        int studentCount;
    };

    Course courses[MAX_COURSES];
    int courseCount;

    // Helper function to find a course index by name
    int findCourseIndex(const string& course) const {
        for (int i = 0; i < courseCount; ++i) {
            if (courses[i].name == course) {
                return i;
            }
        }
        return -1; // Course not found
    }

    // Helper function to find a student index in a course by name
    int findStudentIndex(const Course& course, const string& student) const {
        for (int i = 0; i < course.studentCount; ++i) {
            if (course.students[i] == student) {
                return i;
            }
        }
        return -1; // Student not found
    }

public:
    // Constructors and Destructor
    EnrollmentMap() : courseCount(0) {}                            // Default constructor
    EnrollmentMap(const EnrollmentMap& other) : courseCount(other.courseCount) {  // Copy constructor
        for (int i = 0; i < other.courseCount; ++i) {
            courses[i] = other.courses[i];
        }
    }

    EnrollmentMap& operator=(const EnrollmentMap& other) { // Assignment operator
        if (this != &other) {
            courseCount = other.courseCount;
            for (int i = 0; i < other.courseCount; ++i) {
                courses[i] = other.courses[i];
            }
        }
        return *this;
    }

    ~EnrollmentMap() {} // Destructor

    // Access/modify entries by course
    string& operator[](const string& course) { 
        int index = findCourseIndex(course);
        if (index == -1) {
            if (courseCount < MAX_COURSES) {
                courses[courseCount].name = course;
                courses[courseCount].studentCount = 0;
                index = courseCount++;
            } else {
                throw runtime_error("Maximum number of courses reached.");
            }
        }
        return courses[index].name;
    }

    // Add a student to a course
    EnrollmentMap& operator+=(const pair<string, string>& courseStudentPair) {
        const string& course = courseStudentPair.first;
        const string& student = courseStudentPair.second;
        int index = findCourseIndex(course);
        if (index == -1) {
            if (courseCount < MAX_COURSES) {
                courses[courseCount].name = course;
                courses[courseCount].students[0] = student;
                courses[courseCount].studentCount = 1;
                courseCount++;
            } else {
                throw runtime_error("Maximum number of courses reached.");
            }
        } else {
            if (courses[index].studentCount < MAX_STUDENTS_PER_COURSE) {
                courses[index].students[courses[index].studentCount++] = student;
            } else {
                throw runtime_error("Maximum number of students per course reached.");
            }
        }
        return *this;
    }

    // Remove a student from a course
    EnrollmentMap& operator-=(const pair<string, string>& courseStudentPair) {
        const string& course = courseStudentPair.first;
        const string& student = courseStudentPair.second;
        int courseIndex = findCourseIndex(course);
        if (courseIndex != -1) {
            int studentIndex = findStudentIndex(courses[courseIndex], student);
            if (studentIndex != -1) {
                for (int j = studentIndex; j < courses[courseIndex].studentCount - 1; ++j) {
                    courses[courseIndex].students[j] = courses[courseIndex].students[j + 1];
                }
                courses[courseIndex].studentCount--;
            }
        }
        return *this;
    }

    // Merge two maps into a new map
    EnrollmentMap operator+(const EnrollmentMap& other) const {
        EnrollmentMap merged = *this;
        for (int i = 0; i < other.courseCount; ++i) {
            int index = merged.findCourseIndex(other.courses[i].name);
            if (index == -1) {
                if (merged.courseCount < MAX_COURSES) {
                    merged.courses[merged.courseCount] = other.courses[i];
                    merged.courseCount++;
                } else {
                    throw runtime_error("Maximum number of courses reached.");
                }
            } else {
                for (int j = 0; j < other.courses[i].studentCount; ++j) {
                    if (merged.courses[index].studentCount < MAX_STUDENTS_PER_COURSE) {
                        merged.courses[index].students[merged.courses[index].studentCount++] = other.courses[i].students[j];
                    } else {
                        break;
                    }
                }
            }
        }
        return merged;
    }

    // Convert the map to a string representation
    string toString() const {
        string result;
        for (int i = 0; i < courseCount; ++i) {
            result += courses[i].name + ": ";
            for (int j = 0; j < courses[i].studentCount; ++j) {
                result += courses[i].students[j];
                if (j < courses[i].studentCount - 1) {
                    result += ", ";
                }
            }
            result += "\n";
        }
        return result;
    }
};

int main() {
    EnrollmentMap enrollments1, enrollments2, mergedEnrollments;

    // Adding students to courses
    enrollments1["Math 101"] = "Math 101";
    enrollments1 += make_pair("Math 101", "Alice Smith");
    enrollments1["History 201"] = "History 201";
    enrollments1 += make_pair("History 201", "Bob Johnson");
    enrollments2["Physics 101"] = "Physics 101";
    enrollments2 += make_pair("Physics 101", "Charlie Brown");

    // Adding more students to existing courses
    enrollments1 += make_pair("Math 101", "David Jones");
    enrollments1 += make_pair("Math 101", "Eva Green");
    enrollments2 += make_pair("Physics 101", "Frank White");
    enrollments2 += make_pair("Physics 101", "Grace Black");
    enrollments2 += make_pair("Physics 101", "Hank Blue");
    enrollments2 += make_pair("Physics 101", "Ivy Red");

    // Adding a new course with students
    enrollments2["Chemistry 101"] = "Chemistry 101";
    enrollments2 += make_pair("Chemistry 101", "Jack Gold");
    enrollments2 += make_pair("Chemistry 101", "Karen Silver");
    enrollments2 += make_pair("Chemistry 101", "Leo Bronze");
    enrollments2 += make_pair("Chemistry 101", "Mia Copper");

    // Merging two enrollment maps
    mergedEnrollments = enrollments1 + enrollments2;
    cout << "Merged Enrollments: " << mergedEnrollments.toString() << endl;

    // Removing a student from a course
    enrollments1 -= make_pair("Math 101", "David Jones");
    cout << "Updated Enrollments: " << enrollments1.toString() << endl;

    return 0;
}
