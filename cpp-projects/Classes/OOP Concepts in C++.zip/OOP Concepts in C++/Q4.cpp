#include <iostream>
#include <cstring> // For C-style string functions

using namespace std;

const int MAX_TEXT_LENGTH = 100;
const int MAX_PAGES = 10;
const int MAX_SECTIONS = 10;
const int MAX_LINES = 10;

class Line {
private:
    char text[MAX_TEXT_LENGTH];
public:
    Line() {
        text[0] = '\0';
    }

    Line(const char* t) {
        strncpy(text, t, MAX_TEXT_LENGTH - 1);
        text[MAX_TEXT_LENGTH - 1] = '\0';
    }

    const char* getText() const {
        return text;
    }

    Line& operator+=(const char* t) {
        strncat(text, t, MAX_TEXT_LENGTH - strlen(text) - 1);
        return *this;
    }

    Line operator+(const char* t) const {
        Line newLine(*this);
        newLine += t;
        return newLine;
    }

    // To handle direct assignment
    Line& operator=(const char* t) {
        strncpy(text, t, MAX_TEXT_LENGTH - 1);
        text[MAX_TEXT_LENGTH - 1] = '\0';
        return *this;
    }
};

class Page {
private:
    Line lines[MAX_LINES];
    int lineCount;
public:
    Page() : lineCount(0) {}

    Page& operator+=(const Line& line) {
        if (lineCount < MAX_LINES) {
            lines[lineCount++] = line;
        }
        return *this;
    }

    Line& operator[](int index) {
        return lines[index];
    }

    const Line& operator[](int index) const {
        return lines[index];
    }

    int getLineCount() const {
        return lineCount;
    }
};

class Section {
private:
    Page pages[MAX_PAGES];
    int pageCount;
public:
    Section() : pageCount(0) {}

    Section& operator+=(const Page& page) {
        if (pageCount < MAX_PAGES) {
            pages[pageCount++] = page;
        }
        return *this;
    }

    Page& operator[](int index) {
        return pages[index];
    }

    const Page& operator[](int index) const {
        return pages[index];
    }

    int getPageCount() const {
        return pageCount;
    }
};

class Article {
private:
    Section sections[MAX_SECTIONS];
    int sectionCount;
public:
    Article() : sectionCount(0) {}

    Article& operator+=(const Page& page) {
        if (sectionCount == 0 || sections[sectionCount - 1].getPageCount() >= MAX_PAGES) {
            if (sectionCount < MAX_SECTIONS) {
                sections[sectionCount++] = Section();
            }
        }
        sections[sectionCount - 1] += page;
        return *this;
    }

    Article& operator+=(const Section& section) {
        if (sectionCount < MAX_SECTIONS) {
            sections[sectionCount++] = section;
        }
        return *this;
    }

    Section& operator[](int index) {
        return sections[index];
    }

    const Section& operator[](int index) const {
        return sections[index];
    }

    int getSectionCount() const {
        return sectionCount;
    }
};

int main() {
    Article article;
    Page page1;
    page1 += Line("This is line 1 on page 1.");
    page1 += Line("This is line 2 on page 1.");

    Page page2;
    page2 += Line("This is line 1 on page 2.");

    article += page1;
    article += page2;

    Section section;
    section += page1;
    section += page2;

    article += section;
    
    // Create pages
    Page p1, p2, p3, p4;
    // Add text to pages
    p1 += "The quick brown fox jumps over the lazy dog. This pangram contains every letter of the alphabet, making it a popular sentence for typing practice.";
    p2 += "To be, or not to be, that is the question. Whether 'tis nobler in the mind to suffer the slings and arrows of outrageous fortune.";
    p3 += "All the world's a stage, and all the men and women merely players. They have their exits and their entrances.";
    p4 += "In the beginning, the universe was created. This has made a lot of people very angry and been widely regarded as a bad move.";
    // Create a section and add pages to it
    Section section1;
    section1 += p1;
    section1 += p2;
    section1 += p3;
    // Add the fourth page to the first section
    section1 += p4;
    // Create an article and add sections to it
    article += section1;
    // Create another section with additional pages
    Section section2;
    Page p5, p6;
    p5 += "We hold these truths to be self-evident, that all men are created equal, that they are endowed by their Creator with certain unalienable Rights.";
    p6 += "I have a dream that one day this nation will rise up and live out the true meaning of its creed: 'We hold these truths to be self-evident, that all men are created equal.'";
    section2 += p5;
    section2 += p6;
    // Add the second section to the article
    article += section2;
    // Edit a specific line on a specific page in a specific section
    article[1][1][0] = "This is a new line added to the first page of the second section.";

    cout << "Article content:" << endl;
    for (int i = 0; i < article.getSectionCount(); ++i) {
        const Section& sec = article[i];
        for (int j = 0; j < sec.getPageCount(); ++j) {
            const Page& pg = sec[j];
            for (int k = 0; k < pg.getLineCount(); ++k) {
                cout << pg[k].getText() << endl;
            }
        }
    }

    return 0;
}
