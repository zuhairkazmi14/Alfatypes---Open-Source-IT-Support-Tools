#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>

using namespace std;

class Car {
private:
    string name;
    string dateCrawled;
    string sellerType;
    string offerType;
    double price;
    string abTestingInfo;
    string vehicleType;
    int yearOfRegistration;
    string gearboxType;
    int powerOutputPS;
    string modelOfCar;
    double kilometersDriven;
    int monthOfRegistration;
    string fuelType;
    string brandName;
    bool notRepairedDamage;
    string dateCreated;
    int numOfPictures;
    int postalCode;
    string lastSeen;

    // Helper function to trim leading and trailing spaces
    string trim(const string& str) {
        size_t start = str.find_first_not_of(" \t");
        size_t end = str.find_last_not_of(" \t");
        return (start == string::npos) ? "" : str.substr(start, end - start + 1);
    }

public:
    // Constructor
    Car() : name(""), dateCrawled(""), sellerType(""), offerType(""), price(0.0),
        abTestingInfo(""), vehicleType(""), yearOfRegistration(0),
        gearboxType(""), powerOutputPS(0), modelOfCar(""), kilometersDriven(0.0),
        monthOfRegistration(0), fuelType(""), brandName(""), notRepairedDamage(false),
        dateCreated(""), numOfPictures(0), postalCode(0), lastSeen("") {}

    // Overloading + operator to combine details of 2 cars
    Car operator+(const Car& other) const {
        Car result = *this;
        result.price += other.price;
        result.kilometersDriven += other.kilometersDriven;
        result.numOfPictures += other.numOfPictures;
        result.name += " & " + other.name;
        return result;
    }

    // Overloading += operator to combine details of 2 cars
    Car& operator+=(const Car& other) {
        this->price += other.price;
        this->kilometersDriven += other.kilometersDriven;
        this->numOfPictures += other.numOfPictures;
        this->name += " & " + other.name;
        return *this;
    }

    // Overloading - operator to subtract selling prices of two cars
    double operator-(const Car& other) const {
        return this->price - other.price;
    }

    // Overloading -= operator to subtract details of 2 cars
    Car& operator-=(const Car& other) {
        this->price -= other.price;
        this->kilometersDriven -= other.kilometersDriven;
        this->numOfPictures -= other.numOfPictures;
        return *this;
    }

    // Overloading == operator to compare details of two cars
    bool operator==(const Car& other) const {
        return name == other.name && dateCrawled == other.dateCrawled &&
            sellerType == other.sellerType && offerType == other.offerType &&
            price == other.price && abTestingInfo == other.abTestingInfo &&
            vehicleType == other.vehicleType && yearOfRegistration == other.yearOfRegistration &&
            gearboxType == other.gearboxType && powerOutputPS == other.powerOutputPS &&
            modelOfCar == other.modelOfCar && kilometersDriven == other.kilometersDriven &&
            monthOfRegistration == other.monthOfRegistration && fuelType == other.fuelType &&
            brandName == other.brandName && notRepairedDamage == other.notRepairedDamage &&
            dateCreated == other.dateCreated && numOfPictures == other.numOfPictures &&
            postalCode == other.postalCode && lastSeen == other.lastSeen;
    }

    // Overloading > operator to compare prices of two cars
    bool operator>(const Car& other) const {
        return this->price > other.price;
    }

    // Overloading < operator to compare prices of two cars
    bool operator<(const Car& other) const {
        return this->price < other.price;
    }

    // Overloading >= operator to compare prices of two cars
    bool operator>=(const Car& other) const {
        return this->price >= other.price;
    }

    // Overloading <= operator to compare prices of two cars
    bool operator<=(const Car& other) const {
        return this->price <= other.price;
    }

    // Overloading != operator to compare details of two cars
    bool operator!=(const Car& other) const {
        return !(*this == other);
    }

    // Unary + operator to make all numeric values positive
    Car operator+() const {
        Car result = *this;
        result.price = abs(result.price);
        result.kilometersDriven = abs(result.kilometersDriven);
        return result;
    }

    // Unary - operator to make all numeric values negative
    Car operator-() const {
        Car result = *this;
        result.price = -result.price;
        result.kilometersDriven = -result.kilometersDriven;
        return result;
    }

    // Display car details
    friend ostream& operator<<(ostream& output, const Car& car) {
        output << "Name: " << car.name << "\n"
            << "Date Crawled: " << car.dateCrawled << "\n"
            << "Seller Type: " << car.sellerType << "\n"
            << "Offer Type: " << car.offerType << "\n"
            << "Price: " << car.price << "\n"
            << "AB Testing Info: " << car.abTestingInfo << "\n"
            << "Vehicle Type: " << car.vehicleType << "\n"
            << "Year of Registration: " << car.yearOfRegistration << "\n"
            << "Gearbox Type: " << car.gearboxType << "\n"
            << "Power Output (PS): " << car.powerOutputPS << "\n"
            << "Model of Car: " << car.modelOfCar << "\n"
            << "Kilometers Driven: " << car.kilometersDriven << "\n"
            << "Month of Registration: " << car.monthOfRegistration << "\n"
            << "Fuel Type: " << car.fuelType << "\n"
            << "Brand Name: " << car.brandName << "\n"
            << "Not Repaired Damage: " << (car.notRepairedDamage ? "Yes" : "No") << "\n"
            << "Date Created: " << car.dateCreated << "\n"
            << "Number of Pictures: " << car.numOfPictures << "\n"
            << "Postal Code: " << car.postalCode << "\n"
            << "Last Seen: " << car.lastSeen;
        return output;
    }

    // Input Car Details 
    friend istream& operator>>(istream& input, Car& car) {
        string line;
        getline(input, line); // Read one line from the input
        stringstream ss(line);
        string temp;

        getline(ss, car.name, ',');
        getline(ss, car.dateCrawled, ',');
        getline(ss, car.sellerType, ',');
        getline(ss, car.offerType, ',');
        getline(ss, temp, ','); car.price = atof(temp.c_str());
        getline(ss, car.abTestingInfo, ',');
        getline(ss, car.vehicleType, ',');
        getline(ss, temp, ','); car.yearOfRegistration = atoi(temp.c_str());
        getline(ss, car.gearboxType, ',');
        getline(ss, temp, ','); car.powerOutputPS = atoi(temp.c_str());
        getline(ss, car.modelOfCar, ',');
        getline(ss, temp, ','); car.kilometersDriven = atof(temp.c_str());
        getline(ss, temp, ','); car.monthOfRegistration = atoi(temp.c_str());
        getline(ss, car.fuelType, ',');
        getline(ss, car.brandName, ',');
        getline(ss, temp, ','); car.notRepairedDamage = (temp == "yes");
        getline(ss, car.dateCreated, ',');
        getline(ss, temp, ','); car.numOfPictures = atoi(temp.c_str());
        getline(ss, temp, ','); car.postalCode = atoi(temp.c_str());
        getline(ss, car.lastSeen);

        return input;
    }
};

int main() {
    const int MAX_CARS = 100; // Adjust size as needed
    Car* cars = new Car[MAX_CARS];
    int carCount = 0;

    ifstream file("C:\\Users\\zuhai\\Downloads\\OOP-Summer-2024-Assignment03\\OOP-Summer-2024-Assignment03\\autos.csv");
    if (!file) {
        cerr << "Error opening file." << endl;
        return 1;
    }

    string header;
    getline(file, header); // Skip the header line

    while (carCount < MAX_CARS && file >> cars[carCount]) {
        carCount++;
    }

    file.close();

    // Perform operations on the cars
    if (carCount >= 2) {
        Car combinedCar = cars[0] + cars[1];
        cout << "Combined Car:" << endl << combinedCar << endl;

        cars[0] += cars[1];
        cout << "Updated Car 0:" << endl << cars[0] << endl;

        double priceDifference = cars[0] - cars[1];
        cout << "Price Difference: " << priceDifference << endl;

        cars[0] -= cars[1];
        cout << "After Subtracting Car 1 from Car 0:" << endl << cars[0] << endl;

        cout << "Car 0 == Car 1: " << (cars[0] == cars[1]) << endl;
        cout << "Car 0 > Car 1: " << (cars[0] > cars[1]) << endl;
        cout << "Car 0 < Car 1: " << (cars[0] < cars[1]) << endl;

        Car positiveCar = +cars[0];
        Car negativeCar = -cars[1];
        cout << "Positive Car 0:" << endl << positiveCar << endl;
        cout << "Negative Car 1:" << endl << negativeCar << endl;
    }

    delete[] cars;
    return 0;
}
